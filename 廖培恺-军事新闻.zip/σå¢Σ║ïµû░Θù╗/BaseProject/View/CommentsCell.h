//
//  CommentsCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommentsCell : UITableViewCell

/** 评论时间 */
@property(nonatomic,strong)UILabel *dtimeLb;
/** 评论者所在地区 */
@property(nonatomic,strong)UILabel *ipLb;
/** 评论内容 */
@property(nonatomic,strong)UILabel *msgLb;

@end

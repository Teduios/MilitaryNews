//
//  VideoCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKImageView.h"

@interface VideoCell : UITableViewCell

/** 提示点击的视频图片 */
@property(nonatomic,strong)PKImageView *videophotoLb;

@end

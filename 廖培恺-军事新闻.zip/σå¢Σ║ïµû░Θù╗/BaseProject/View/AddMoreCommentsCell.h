//
//  AddMoreCommentsCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddMoreCommentsCell : UITableViewCell
@property(nonatomic,strong)UILabel *moreCommentsLb;
@end

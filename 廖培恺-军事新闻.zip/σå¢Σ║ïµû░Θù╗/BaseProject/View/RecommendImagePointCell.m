//
//  RecommendImagePointCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/26.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RecommendImagePointCell.h"

@implementation RecommendImagePointCell

- (NSArray<PKImageView *> *)image_arr
{
    if (!_image_arr) {
        _image_arr = [[NSArray alloc]initWithObjects:[PKImageView new], [PKImageView new], [PKImageView new], nil];
    }
    return _image_arr;
}

- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont systemFontOfSize:15];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}

- (UILabel *)pubDataLb
{
    if (!_pubDataLb) {
        _pubDataLb = [[UILabel alloc]init];
        _pubDataLb.font = [UIFont systemFontOfSize:12];
        _pubDataLb.textColor = [UIColor grayColor];
    }
    return _pubDataLb;
}

- (UILabel *)plLb
{
    if (!_plLb) {
        _plLb = [[UILabel alloc]init];
        _plLb.font = [UIFont systemFontOfSize:12];
        _plLb.textColor = [UIColor grayColor];
    }
    return _plLb;
}

- (UILabel *)diggLb
{
    if (!_diggLb) {
        _diggLb = [[UILabel alloc]init];
        _diggLb.font = [UIFont systemFontOfSize:12];
        _diggLb.textColor = [UIColor grayColor];
    }
    return _diggLb;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.image_arr[0]];
        [self.contentView addSubview:self.image_arr[1]];
        [self.contentView addSubview:self.image_arr[2]];
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.pubDataLb];
        [self.contentView addSubview:self.plLb];
        [self.contentView addSubview:self.diggLb];
    }
    [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(22);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
    }];
    [_image_arr[0] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(_titleLb.mas_bottomMargin).mas_equalTo(15);
        make.size.mas_equalTo(CGSizeMake(93, 75));
    }];
    [_image_arr[1] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_image_arr[0].mas_rightMargin).mas_equalTo(15);
        make.top.mas_equalTo(_titleLb.mas_bottomMargin).mas_equalTo(15);
        make.size.mas_equalTo(CGSizeMake(93, 75));
    }];
    [_image_arr[2] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_image_arr[1].mas_rightMargin).mas_equalTo(15);
        make.top.mas_equalTo(_titleLb.mas_bottomMargin).mas_equalTo(15);
        make.size.mas_equalTo(CGSizeMake(93, 75));
    }];
    
    /** 发布日期 */
    [_pubDataLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_image_arr[0].mas_bottomMargin).mas_equalTo(15);
        make.left.mas_equalTo(10);
    }];
    
    /** 评论数 */
    [self.plLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_image_arr[0].mas_bottomMargin).mas_equalTo(15);
        make.right.mas_equalTo(-60);
    }];
    
    /** 点赞 */
    [self.diggLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_image_arr[0].mas_bottomMargin).mas_equalTo(15);
        make.right.mas_equalTo(-13);
    }];
    
    return self;
}


















@end


































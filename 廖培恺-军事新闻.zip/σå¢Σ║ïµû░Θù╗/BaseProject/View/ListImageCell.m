//
//  ListImageCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ListImageCell.h"

@implementation ListImageCell


- (PKImageView *)picV
{
    if (!_picV) {
        _picV = [[PKImageView alloc]init];
    }
    return _picV;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.picV];
    }
    [_picV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.size.mas_equalTo(CGSizeMake(280, 180));
        make.centerX.mas_equalTo(0);
        make.top.mas_equalTo(8);
    }];
    return self;
}








@end

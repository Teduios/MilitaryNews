//
//  VideoCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCell.h"

@implementation VideoCell

- (PKImageView *)videophotoLb
{
    if (!_videophotoLb) {
        _videophotoLb = [[PKImageView alloc]init];
    }
    return _videophotoLb;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.videophotoLb];
    }
    /** 播放图片 */
    [_videophotoLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];

    return self;
}







@end





















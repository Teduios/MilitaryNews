//
//  ContentsCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ContentsCell.h"

@implementation ContentsCell

- (UILabel *)contentsLb
{
    if (!_contentsLb) {
        _contentsLb = [[UILabel alloc]init];
        _contentsLb.font = [UIFont systemFontOfSize:14];
        _contentsLb.numberOfLines = 0;
    }
    return _contentsLb;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.contentsLb];
    }

    [_contentsLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(10);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
    }];
    
    return self;
}





@end






















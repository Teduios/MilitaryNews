//
//  TitleCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleCell : UITableViewCell
/** 题目标签 */
@property(nonatomic,strong)UILabel *titleLb;
/** 发布的日期 */
@property(nonatomic,strong)UILabel *pubDataLb;
/** 作者 */
@property(nonatomic,strong)UILabel *authorLb;
/** 阅读量 */
@property(nonatomic,strong)UILabel *clickLb;
/** 支持 */
@property(nonatomic,strong)UIButton *goodpostBtn;
/** 反对 */
@property(nonatomic,strong)UIButton *bagpostBtn;
/** 文字段落 */
@property(nonatomic,strong)UILabel *contentsLb;

/** 评论里面的属性 */
/** 评论时间 */
@property(nonatomic,strong)UILabel *dtimeLb;
/** 评论者所在地区 */
@property(nonatomic,strong)UILabel *ipLb;
/** 评论内容 */
@property(nonatomic,strong)UILabel *msg;
/** 评论者名称 */
@property(nonatomic,strong)UILabel *usernameLb;








@end



















//
//  ShareCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShareCell.h"
#import "UMSocial.h"
#import "ListRecommendViewModel.h"

@interface ShareCell ()

@end

@implementation ShareCell

- (UIButton *)goodpostBtn
{
    if (!_goodpostBtn) {
        _goodpostBtn = [UIButton buttonWithType:0];
        [_goodpostBtn setImage:[UIImage imageNamed:@"good"] forState:0];
        [_goodpostBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, -20, 0)];
        [_goodpostBtn setTitleColor:kRGBColor(182, 216, 79) forState:0];
    }
    return _goodpostBtn;
}
- (UIButton *)bagpostBtn
{
    if (!_bagpostBtn) {
        _bagpostBtn = [UIButton buttonWithType:0];
        [_bagpostBtn setImage:[UIImage imageNamed:@"bag"] forState:0];
        [_bagpostBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, -20, 0)];
        [_bagpostBtn setTitleColor:kRGBColor(206, 59, 65) forState:0];
    }
    return _bagpostBtn;
}

- (UIButton *)shareBtn
{
    if (!_shareBtn) {
        _shareBtn = [UIButton buttonWithType:0];
        [_shareBtn setImage:[UIImage imageNamed:@"share"] forState:0];
        [_shareBtn setTitle:@"乐在分享..." forState:0];
        _shareBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [_shareBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, -20, 0)];
        [_shareBtn setTitleColor:kRGBColor(58, 164, 238) forState:0];
        [_shareBtn addTarget:self action:@selector(shareWeibo) forControlEvents:UIControlEventTouchUpInside];
    }
    return _shareBtn;
}

- (UILabel *)shareLb
{
    if (!_shareLb) {
        _shareLb = [[UILabel alloc]init];
        _shareLb.numberOfLines = 0;
        _shareLb.font = [UIFont systemFontOfSize:13];
        _shareLb.backgroundColor = [UIColor grayColor];
        _shareLb.text = @"您的支持与分享是我们的动力...";
        _shareLb.textAlignment = NSTextAlignmentCenter;
    }
    return _shareLb;
}

//- (PKImageView *)imageV
//{
//    if (!_imageV) {
//        _imageV = [[PKImageView alloc]initWithFrame:CGRectMake(40, 50, 55, 45)];
//    }
//    return _imageV;
//}

- (UILabel *)commentLb
{
    if (!_commentLb) {
        _commentLb = [[UILabel alloc]init];
        _commentLb.textColor = kRGBColor(122, 176, 100);
        _commentLb.font = [UIFont systemFontOfSize:16];
    }
    return _commentLb;
}


/** 
 * 点击分享微博按钮触发
 */
- (void)shareWeibo
{
    NSString *path = self.pageUrl;
    NSString *str = [path stringByAppendingString:self.title];
    
    
    //注意：分享到微信好友、微信朋友圈、微信收藏、QQ空间、QQ好友、来往好友、来往朋友圈、易信好友、易信朋友圈、Facebook、Twitter、Instagram等平台需要参考各自的集成方法
    [UMSocialSnsService presentSnsIconSheetView:[self viewController]
                                         appKey:@"564ff946e0f55a4693002aeb"
                                      shareText:str
                                     shareImage:self.image
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToQQ,nil]
                                       delegate:nil];
}

/**
 * 获得当前view的控制器
 */
- (UIViewController*)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.goodpostBtn];
        [self.contentView addSubview:self.bagpostBtn];
        [self.contentView addSubview:self.shareBtn];
        [self.contentView addSubview:self.shareLb];
        [self.contentView addSubview:self.commentLb];
    }
    [_shareLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(0);
        make.top.mas_equalTo(30);
        make.right.mas_equalTo(0);
    }];
    
    [_goodpostBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(self.shareLb.mas_bottomMargin).mas_equalTo(10);
    }];
    
    [_bagpostBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.goodpostBtn.mas_rightMargin).mas_equalTo(20);
        make.top.mas_equalTo(self.shareLb.mas_bottomMargin).mas_equalTo(10);
    }];
    
    [_shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(220);
        make.top.mas_equalTo(self.shareLb.mas_bottomMargin).mas_equalTo(13);
    }];
    
    [_commentLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(self.goodpostBtn.mas_bottomMargin).mas_equalTo(30);
    }];
    
    
    return self;
}



@end























//
//  CommentsCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CommentsCell.h"

@implementation CommentsCell

- (UILabel *)dtimeLb
{
    if (!_dtimeLb) {
        _dtimeLb = [[UILabel alloc]init];
        _dtimeLb.font = [UIFont systemFontOfSize:12];
        _dtimeLb.textColor = [UIColor grayColor];
    }
    return _dtimeLb;
}
- (UILabel *)ipLb
{
    if (!_ipLb) {
        _ipLb = [[UILabel alloc]init];
        _ipLb.font = [UIFont systemFontOfSize:12];
        _ipLb.textColor = [UIColor grayColor];
    }
    return _ipLb;
}
- (UILabel *)msgLb
{
    if (!_msgLb) {
        _msgLb = [[UILabel alloc]init];
        _msgLb.font = [UIFont systemFontOfSize:13];
        _msgLb.numberOfLines = 0;
    }
    return _msgLb;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.msgLb];
        [self.contentView addSubview:self.ipLb];
        [self.contentView addSubview:self.dtimeLb];
    }
    
    [_dtimeLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(10);
    }];
    [_ipLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.dtimeLb.mas_rightMargin).mas_equalTo(20);
        make.top.mas_equalTo(10);
    }];
    [_msgLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(self.ipLb.mas_bottomMargin).mas_equalTo(10);
        make.right.mas_equalTo(-10);
    }];
    
    return self;
}




















@end














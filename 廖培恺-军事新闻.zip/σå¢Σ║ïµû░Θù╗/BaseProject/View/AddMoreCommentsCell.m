//
//  AddMoreCommentsCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AddMoreCommentsCell.h"

@implementation AddMoreCommentsCell

- (UILabel *)moreCommentsLb
{
    if (!_moreCommentsLb) {
        _moreCommentsLb = [[UILabel alloc]init];
        _moreCommentsLb.textColor = [UIColor grayColor];
        _moreCommentsLb.font = [UIFont systemFontOfSize:14];
        _moreCommentsLb.textAlignment = NSTextAlignmentCenter;
    }
    return _moreCommentsLb;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.moreCommentsLb];
    }
    [_moreCommentsLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    return self;
}


@end

//
//  recommendCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "recommendCell.h"

@implementation recommendCell

- (PKImageView *)imageV
{
    if (!_imageV) {
        _imageV = [[PKImageView alloc]init];
    }
    return _imageV;
}

- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont systemFontOfSize:15];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}

- (UILabel *)pubDataLb
{
    if (!_pubDataLb) {
        _pubDataLb = [[UILabel alloc]init];
        _pubDataLb.font = [UIFont systemFontOfSize:12];
        _pubDataLb.textColor = [UIColor grayColor];
    }
    return _pubDataLb;
}

- (UILabel *)plLb
{
    if (!_plLb) {
        _plLb = [[UILabel alloc]init];
        _plLb.font = [UIFont systemFontOfSize:12];
        _plLb.textColor = [UIColor grayColor];
    }
    return _plLb;
}

- (UILabel *)diggLb
{
    if (!_diggLb) {
        _diggLb = [[UILabel alloc]init];
        _diggLb.font = [UIFont systemFontOfSize:12];
        _diggLb.textColor = [UIColor grayColor];
    }
    return _diggLb;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.imageV];
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.pubDataLb];
        [self.contentView addSubview:self.plLb];
        [self.contentView addSubview:self.diggLb];
    }
    /** 图片 宽高92,70 左10, 竖向居中 */
    [self.imageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.size.mas_equalTo(CGSizeMake(83, 83));
        // 竖向居中
        make.centerY.mas_equalTo(0);
    }];
    /** 题目 距离图片右边缘8,距离cell右边缘10,上边缘比图片上边缘矮3 */
    [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_imageV.mas_right).mas_equalTo(8);
        make.right.mas_equalTo(-10);
        make.topMargin.mas_equalTo(_imageV.mas_topMargin).mas_equalTo(3);
    }];
    /** 发布日期 距离图片右边缘8 */
    [self.pubDataLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_imageV.mas_right).mas_equalTo(8);
        make.right.mas_equalTo(-140);
        make.topMargin.mas_equalTo(_imageV.mas_bottomMargin).mas_equalTo(0);
    }];
    /** 评论数 */
    [self.plLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottomMargin.mas_equalTo(_imageV.mas_bottomMargin);
        make.right.mas_equalTo(-60);
    }];
    /** 点赞 */
    [self.diggLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottomMargin.mas_equalTo(_imageV.mas_bottomMargin);
        make.right.mas_equalTo(_titleLb.mas_rightMargin);
    }];
    return self;
}






@end




































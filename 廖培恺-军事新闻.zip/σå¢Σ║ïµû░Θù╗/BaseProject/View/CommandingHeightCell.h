//
//  CommandingHeightCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKImageView.h"

@interface CommandingHeightCell : UITableViewCell
/** 图片标签 */
@property(nonatomic,strong)PKImageView *imageV;
/** 题目标签 */
@property(nonatomic,strong)UILabel *titleLb;
/** 时间标签 */
@property(nonatomic,strong)UILabel *pubDataLb;
/** 评论标签 */
@property(nonatomic,strong)UILabel *plLb;
/** 点赞标签 */
@property(nonatomic,strong)UILabel *diggLb;
@end

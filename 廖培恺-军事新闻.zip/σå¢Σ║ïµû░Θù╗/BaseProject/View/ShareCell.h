//
//  ShareCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKImageView.h"

@interface ShareCell : UITableViewCell

/** 用于接收传入分享页面的URL */
@property(nonatomic,strong)NSString *pageUrl;
/** 用于接收传入的title */
@property(nonatomic,strong)NSString *title;


/** 支持 */
@property(nonatomic,strong)UIButton *goodpostBtn;
/** 反对 */
@property(nonatomic,strong)UIButton *bagpostBtn;
/** 分享到微博 */
@property(nonatomic,strong)UIButton *shareBtn;
/** 分享文字提醒 */
@property(nonatomic,strong)UILabel *shareLb;
/** 原始图片 */
//@property(nonatomic,strong)PKImageView *imageV;
/** 精彩评论标签 */
@property(nonatomic,strong)UILabel *commentLb;

@end

//
//  PKImageView.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PKImageView : UIView
@property(nonatomic,strong)UIImageView *imageView;
@end

//
//  ContentsCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContentsCell : UITableViewCell
/** 文字段落 */
@property(nonatomic,strong)UILabel *contentsLb;
@end

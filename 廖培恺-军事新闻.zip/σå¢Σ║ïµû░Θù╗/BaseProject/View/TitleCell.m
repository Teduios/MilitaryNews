//
//  TitleCell.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TitleCell.h"

@implementation TitleCell

- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont systemFontOfSize:17];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}
- (UILabel *)pubDataLb
{
    if (!_pubDataLb) {
        _pubDataLb = [[UILabel alloc]init];
        _pubDataLb.font = [UIFont systemFontOfSize:12];
        _pubDataLb.textColor = [UIColor grayColor];
    }
    return _pubDataLb;
}
- (UILabel *)authorLb
{
    if (!_authorLb) {
        _authorLb = [[UILabel alloc]init];
        _authorLb.font = [UIFont systemFontOfSize:12];
        _authorLb.textColor = [UIColor grayColor];
    }
    return _authorLb;
}
- (UILabel *)clickLb
{
    if (!_clickLb) {
        _clickLb = [[UILabel alloc]init];
        _clickLb.font = [UIFont systemFontOfSize:12];
        _clickLb.textColor = [UIColor grayColor];
    }
    return _clickLb;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.pubDataLb];
        [self.contentView addSubview:self.authorLb];
        [self.contentView addSubview:self.clickLb];
    }
    
    [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(5);
        make.right.mas_equalTo(-5);
    }];
    [self.pubDataLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(self.titleLb.mas_bottomMargin).mas_equalTo(10);
    }];
    [self.authorLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.titleLb.mas_bottomMargin).mas_equalTo(10);
        make.left.mas_equalTo(self.pubDataLb.mas_rightMargin).mas_equalTo(18);
    }];
    [self.clickLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-30);
        make.top.mas_equalTo(self.titleLb.mas_bottomMargin).mas_equalTo(10);
    }];
    return self;
}

@end

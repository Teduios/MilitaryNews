//
//  ListImageCell.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKImageView.h"

@interface ListImageCell : UITableViewCell

/** pic中的图片 */
@property(nonatomic,strong)PKImageView *picV;
@end

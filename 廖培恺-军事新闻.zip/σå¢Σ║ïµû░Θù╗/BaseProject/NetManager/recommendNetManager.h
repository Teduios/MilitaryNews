//
//  recommendNetManager.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "recommendModel.h"
#import "ListRecommendModel.h"
#import "PicsModel.h"
#import "ActionModel.h"
#import "CommentsModel.h"
#import "MoreCommentsModel.h"
#import "VideoModel.h"

typedef NS_ENUM(NSUInteger, ActType) {
    ActTypeIndex,      // 推荐
    ActTypeFenghuo,    // 制高点
    ActTypeTuWen,      // 图片控
    ActType2,          // 大视野
    ActType6,          // 读点史
    ActTypeVideo,      // 流媒体
};

@interface recommendNetManager : BaseNetManager
/**
 *  获取推荐,制高点,图片控,大视野,读点史,流媒体
 *
 *  @param type (推荐,制高点,图片控,大视野,读点史,流媒体)
 *
 *  @param page 请求页数
 *
 *  @return 网络请求任务
 */
+ (id)getRecommendWithType:(ActType)type page:(NSInteger)page kCompletionHandle;


/**
 *  获取资讯的详情页
 *
 *  @param aid 资讯详情aid
 *
 *  @param page 请求页数
 *
 *  @return 网络请求任务
 */
+ (id)getListDetailRecommendWithAid:(NSString *)aid type:(ActType)type kCompletionHandle;

/**
 *  点击了支持或反对事件(点赞)
 *
 *  @param aid 资讯详情aid
 *
 *  @param action 支持或者反对
 *
 *  @return 网络请求任务
 */
+ (id)getMannerWithID:(NSString *)ID action:(NSString *)action kCompletionHandle;

/**
 *  点击加载更多评论
 *
 *  @param aid 资讯详情aid
 *
 *  @param page 每次请求多少条评论
 *
 *  @return 网络请求任务
 */
+ (id)getCommentsListWithPage:(NSInteger)page aid:(NSString *)aid kCompletionHandle;

/**
 *  发送评论
 *
 *  @param mod 要发送的评论内容
 *
 *  @return 网络发送任务
 */
+ (id)postMsgWithMsg:(NSString *)msg aid:(NSString *)aid username:(NSString *)username kCompletionHandle;

/**
 *  播放视频
 *
 *  @param aid 资讯详情aid
 *
 *  @param page 请求页数
 *
 *  @return 网络请求任务
 */
+ (id)getVideoDetailRecommendWithAid:(NSString *)aid type:(ActType)type kCompletionHandle;


@end

















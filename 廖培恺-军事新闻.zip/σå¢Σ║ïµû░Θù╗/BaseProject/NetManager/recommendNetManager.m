//
//  recommendNetManager.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "recommendNetManager.h"

#define kMod @"mod":@"newslist"
#define kListMod @"mod":@"show"
#define kCommentsMod @"mod":@"dc"
#define kCommentsListMod @"mod":@"commentslist"
#define kNum @"num":@20
#define kAddcomments @"mod":@"addcomments"

@implementation recommendNetManager

+ (id)getRecommendWithType:(ActType)type page:(NSInteger)page completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"page":@(page), kMod}];
    
    switch (type) {
        case ActTypeIndex:
            [params setObject:@"index" forKey:@"act"];
            break;
        case ActTypeFenghuo:
            [params setObject:@"fenghuo" forKey:@"act"];
            break;
        case ActTypeTuWen:
            [params setObject:@"tuwen" forKey:@"act"];
            break;
        case ActType2:
            [params setObject:@"2" forKey:@"act"];
            break;
        case ActType6:
            [params setObject:@"6" forKey:@"act"];
            break;
        case ActTypeVideo:
            [params setObject:@"video" forKey:@"act"];
            break;
            
        default:
            NSAssert(NO, @"%s:type类型不正确", __func__);
            break;
    }
    
    return [self GET:@"http://if.wap.xinjunshi.com/ifios/app_v2.php" parameters:params completionHandler:^(id responseObj, NSError *error) {
        
        switch (type) {
            case ActTypeIndex:
                completionHandle([recommendModel objectWithKeyValues:responseObj], error);
                break;
            case ActTypeFenghuo:
                completionHandle([recommendModel objectWithKeyValues:responseObj], error);
                break;
            case ActTypeTuWen:
                completionHandle([recommendModel objectWithKeyValues:responseObj], error);
                break;
            case ActType2:
                completionHandle([recommendModel objectWithKeyValues:responseObj], error);
                break;
            case ActType6:
                completionHandle([recommendModel objectWithKeyValues:responseObj], error);
                break;
            case ActTypeVideo:
                completionHandle([recommendModel objectWithKeyValues:responseObj], error);
                break;
                
            default:

                break;
        }
    }];
    
}

/** 详情页请求 */
+ (id)getListDetailRecommendWithAid:(NSString *)aid type:(ActType)type completionHandle:(void (^)(id, NSError *))completionHandle
{
    // http://if.wap.xinjunshi.com/ifios/app_v2.php"
    
    NSString *path = @"http://if.wap.xinjunshi.com/ifios/app_v2.php";
    
    NSDictionary *params = @{kListMod, @"aid":aid, @"type":@(type)};
    
    return [self GET:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        
        completionHandle([ListRecommendModel objectWithKeyValues:responseObj], error);
    
    }];
}

/** 发送支持或者反对消息 */
+ (id)getMannerWithID:(NSString *)ID action:(NSString *)action completionHandle:(void (^)(id, NSError *))completionHandle
{
    // http://if.wap.xinjunshi.com/ifios/app_v2.php?mod=dc&action=good&id=135775
    NSString *path = @"http://if.wap.xinjunshi.com/ifios/app_v2.php";
    NSDictionary *params = @{@"id":ID, @"action":action, kCommentsMod};
    return [self GET:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ActionModel objectWithKeyValues:responseObj], error);
    }];
}

/** 发送评论 */
+ (id)postMsgWithMsg:(NSString *)msg aid:(NSString *)aid username:(NSString *)username kCompletionHandle
{
    // POST http://if.wap.xinjunshi.com/ifios/app_v2.php?mod=addcomments
    // username=%B6%C0%C9%C6%C6%E4%C9%ED&msg=%BC%B1%BC%B1%BC%B1&aid=136510
    
    NSDictionary *params = @{kAddcomments, @"msg":msg, @"aid":aid, @"username":username};
    
    NSString *path = @"http://if.wap.xinjunshi.com/ifios/app_v2.php";
    
    return [self POST:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([CommentsModel objectWithKeyValues:responseObj], error);
    }];
}


/** 获取更多评论 */
+ (id)getCommentsListWithPage:(NSInteger)page aid:(NSString *)aid kCompletionHandle
{
    // http://if.wap.xinjunshi.com/ifios/app_v2.php?mod=commentslist&aid=135602&page=1&num=20
    NSString *path = @"http://if.wap.xinjunshi.com/ifios/app_v2.php";
    NSDictionary *params = @{kCommentsListMod, kNum, @"aid":aid, @"page":@(page)};
    return [self GET:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([MoreCommentsModel objectWithKeyValues:responseObj], error);
    }];
}


/** 播放视频请求 */
+ (id)getVideoDetailRecommendWithAid:(NSString *)aid type:(ActType)type completionHandle:(void (^)(id, NSError *))completionHandle
{
    // http://if.wap.xinjunshi.com/ifios/app_v2.php"
    
    NSString *path = @"http://if.wap.xinjunshi.com/ifios/app_v2.php";
    
    NSDictionary *params = @{kListMod, @"aid":aid, @"type":@(type)};
    
    return [self GET:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        
        completionHandle([VideoModel objectWithKeyValues:responseObj], error);
        
    }];
}








@end




























//
//  ListRecommendModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ListRecommendModel.h"

@implementation ListRecommendModel

@end
@implementation ListRecommendDataModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"descriptionk":@"description"};
}
@end


@implementation ListRecommendCommentsModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [ListRecommendListModel class]};
}

@end


@implementation ListRecommendListModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}
@end



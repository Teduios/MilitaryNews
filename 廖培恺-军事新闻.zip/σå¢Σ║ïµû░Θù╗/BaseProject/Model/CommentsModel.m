//
//  CommentsModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CommentsModel.h"

@implementation CommentsModel

@end
@implementation CommentsDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [CommentsListModel class]};
}

@end


@implementation CommentsListModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}
@end



//
//  recommendModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "recommendModel.h"

@implementation recommendModel

@end

@implementation recommendDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"nav" : [recommendNavModel class], @"slide" : [recommendSlideModel class], @"item" : [recommendItemModel class]};
}

@end


@implementation recommendTitleModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"typenamek":@"typename", @"descriptionk":@"description"};
}
@end


@implementation recommendNavModel

@end


@implementation recommendSlideModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"descriptionk":@"description"};
}
@end


@implementation recommendItemModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"descriptionk":@"description"};
}
@end



//
//  recommendModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//  首页
 
#import "BaseModel.h"

@class recommendItemModel,recommendDataModel,recommendTitleModel,recommendNavModel,recommendSlideModel;

@interface recommendModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) recommendDataModel *data;

@property (nonatomic, copy) NSString *mod;

@end

@interface recommendDataModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<recommendNavModel *> *nav;

@property (nonatomic, strong) recommendTitleModel *title;

@property (nonatomic, strong) NSArray<recommendItemModel *> *item;

@property (nonatomic, strong) NSArray<recommendSlideModel *> *slide;

@property (nonatomic, assign) NSInteger maxpage;

@end

@interface recommendTitleModel : BaseModel

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *typenamek;

@property (nonatomic, copy) NSString *descriptionk;

@end

@interface recommendNavModel : BaseModel

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *url;

@end

/** 滚动栏 */
@interface recommendSlideModel : BaseModel

@property (nonatomic, copy) NSString *category;

@property (nonatomic, copy) NSString *channel;

@property (nonatomic, assign) NSInteger news_show_type;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *digg;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *aid;

@property (nonatomic, copy) NSString *pubDate;

@property (nonatomic, copy) NSString *descriptionk;

@property (nonatomic, copy) NSString *pl;

@end

@interface recommendItemModel : BaseModel

@property (nonatomic, copy) NSString *category;

@property (nonatomic, copy) NSString *channel;

@property (nonatomic, assign) NSInteger news_show_type;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *digg;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSArray <NSString *> *image_arr;

@property (nonatomic, copy) NSString *aid;

@property (nonatomic, copy) NSString *pubDate;

@property (nonatomic, copy) NSString *descriptionk;

@property (nonatomic, copy) NSString *pl;

@end


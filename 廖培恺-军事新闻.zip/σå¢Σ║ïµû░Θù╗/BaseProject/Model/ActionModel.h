//
//  ActionModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//  点赞或反对

#import "BaseModel.h"

@class ActionDataModel;
@interface ActionModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) ActionDataModel *data;

@property (nonatomic, copy) NSString *mod;

@end

@interface ActionDataModel : BaseModel

@property (nonatomic, copy) NSString *badpost;

@property (nonatomic, assign) NSInteger goodpost;

@end


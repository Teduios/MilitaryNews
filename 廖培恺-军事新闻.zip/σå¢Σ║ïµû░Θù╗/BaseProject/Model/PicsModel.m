//
//  PicsModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicsModel.h"

@implementation PicsModel

@end
@implementation PicsDataModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"descriptionk":@"description"};
}

+ (NSDictionary *)objectClassInArray{
    return @{@"pics" : [PicsPicsModel class]};
}

@end


@implementation PicsCommentsModel

@end


@implementation PicsPicsModel

@end



//
//  CommentsModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//  发表评论

#import "BaseModel.h"

@class CommentsDataModel,CommentsListModel;
@interface CommentsModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) CommentsDataModel *data;

@property (nonatomic, copy) NSString *mod;

@end
@interface CommentsDataModel : BaseModel

@property (nonatomic, copy) NSString *count;

@property (nonatomic, assign) NSInteger maxpage;

@property (nonatomic, strong) NSArray<CommentsListModel *> *list;

@end

@interface CommentsListModel : BaseModel

@property (nonatomic, copy) NSString *username;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, copy) NSString *ip;

@property (nonatomic, copy) NSString *dtime;

@end


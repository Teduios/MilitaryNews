//
//  VideoModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoModel.h"

@implementation VideoModel

@end


@implementation VideoDataModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"descriptionk":@"description"};
}
@end


@implementation VideoCommentsModel

@end



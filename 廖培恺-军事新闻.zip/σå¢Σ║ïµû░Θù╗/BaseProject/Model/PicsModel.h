

//
//  PicsModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//  图片浏览

#import "BaseModel.h"

@class PicsDataModel,PicsCommentsModel,PicsPicsModel;
@interface PicsModel : BaseModel
@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) PicsDataModel *data;

@property (nonatomic, copy) NSString *mod;
@end

@interface PicsDataModel : BaseModel

@property (nonatomic, copy) NSString *descriptionk;

@property (nonatomic, copy) NSString *category;

@property (nonatomic, strong) PicsCommentsModel *comments;

@property (nonatomic, copy) NSString *badpost;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *click;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *pubDate;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *goodpost;

@property (nonatomic, strong) NSArray<PicsPicsModel *> *pics;

@property (nonatomic, strong) NSArray<NSString *> *content;

@end

@interface PicsCommentsModel : BaseModel

@property (nonatomic, copy) NSString *count;

@end

@interface PicsPicsModel : BaseModel

@property (nonatomic, copy) NSString *picstext;

@property (nonatomic, copy) NSString *width;

@property (nonatomic, copy) NSString *height;

@property (nonatomic, copy) NSString *url;

@end


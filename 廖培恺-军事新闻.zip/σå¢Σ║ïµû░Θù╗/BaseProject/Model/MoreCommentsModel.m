//
//  MoreCommentsModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MoreCommentsModel.h"

@implementation MoreCommentsModel

@end
@implementation MoreComentsDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [MoreCommentsListModel class]};
}

@end


@implementation MoreCommentsListModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}
@end



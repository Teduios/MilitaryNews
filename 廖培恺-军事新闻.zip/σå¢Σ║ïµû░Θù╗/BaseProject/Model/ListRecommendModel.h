//
//  ListRecommendModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//  详情页

#import "BaseModel.h"

@class ListRecommendDataModel,ListRecommendCommentsModel,ListRecommendListModel;

@interface ListRecommendModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) ListRecommendDataModel *data;

@property (nonatomic, copy) NSString *mod;

@end

@interface ListRecommendDataModel : NSObject

@property (nonatomic, copy) NSString *descriptionk;

@property (nonatomic, copy) NSString *category;

@property (nonatomic, strong) ListRecommendCommentsModel *comments;

@property (nonatomic, copy) NSString *badpost;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *click;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *pubDate;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *goodpost;

@property (nonatomic, strong) NSArray<NSString *> *pics;

@property (nonatomic, strong) NSArray<NSString *> *content;

@end

/** 评论 */
@interface ListRecommendCommentsModel : NSObject

@property (nonatomic, copy) NSString *count;

@property (nonatomic, strong) NSArray<ListRecommendListModel *> *list;

@end
/** 评论的具体信息 */
@interface ListRecommendListModel : NSObject

@property (nonatomic, copy) NSString *username;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, copy) NSString *ip;

@property (nonatomic, copy) NSString *dtime;

@end


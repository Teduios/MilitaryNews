//
//  ActionModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ActionModel.h"

@implementation ActionModel
+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [ActionDataModel class]};
}
@end
@implementation ActionDataModel

@end



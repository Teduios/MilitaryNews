//
//  MoreCommentsModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//  加载更多评论

#import "BaseModel.h"

@class MoreComentsDataModel,MoreCommentsListModel;
@interface MoreCommentsModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) MoreComentsDataModel *data;

@property (nonatomic, copy) NSString *mod;

@end
@interface MoreComentsDataModel : NSObject

@property (nonatomic, copy) NSString *count;

@property (nonatomic, assign) NSInteger maxpage;

@property (nonatomic, strong) NSArray<MoreCommentsListModel *> *list;

@end

@interface MoreCommentsListModel : NSObject

@property (nonatomic, copy) NSString *username;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, copy) NSString *ip;

@property (nonatomic, copy) NSString *dtime;

@end


//
//  VideoModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class VideoDataModel,VideoCommentsModel;
@interface VideoModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) VideoDataModel *data;

@property (nonatomic, copy) NSString *mod;

@end

@interface VideoDataModel : NSObject

@property (nonatomic, copy) NSString *descriptionk;

@property (nonatomic, copy) NSString *video_play;

@property (nonatomic, copy) NSString *category;

@property (nonatomic, strong) VideoCommentsModel *comments;

@property (nonatomic, copy) NSString *badpost;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *click;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *video_photo;

@property (nonatomic, copy) NSString *pubDate;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *goodpost;

@property (nonatomic, copy) NSString *video_html;

@property (nonatomic, strong) NSArray *pics;

@property (nonatomic, strong) NSArray<NSString *> *content;

@end

@interface VideoCommentsModel : NSObject

@property (nonatomic, copy) NSString *count;

@end


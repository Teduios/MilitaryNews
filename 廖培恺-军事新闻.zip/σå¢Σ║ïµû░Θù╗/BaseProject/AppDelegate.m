//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "recommendViewController.h"
#import "rollBarViewController.h"
#import "UMSocial.h"
#import "LeftViewController.h"

// 添加友盟应用Appkey:564ff946e0f55a4693002aeb
// 微博:
// App Key：3588876399
// App Secret：e19b6ffe0043f86e85bb5ed6be60ccbf
@interface AppDelegate ()

@end
@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self initializeWithApplication:application];

    [self performSelector:@selector(showView) withObject:nil afterDelay:0.0f];
    
    self.window.rootViewController = self.sideMenu;
    // 配置全局同意UI的样式
    [self configGlobalUIStyle];
    
    // 设置友盟AppKey
    [UMSocialData setAppKey:@"564ff946e0f55a4693002aeb"];
   
    
    return YES;
}

/** 配置全局同意UI的样式 */
- (void)configGlobalUIStyle
{
    /** 导航栏不透明 */
    [[UINavigationBar appearance] setTranslucent:NO];
    /** 设置导航栏背景图 */
    
    /** 配置导航栏题目的样式 */
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName:[UIFont flatFontOfSize:17], NSForegroundColorAttributeName:[UIColor blackColor]}];
}

- (UIWindow *)window
{
    if (!_window) {
        _window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}

- (RESideMenu *)sideMenu
{
    if (!_sideMenu) {
        _sideMenu = [[RESideMenu alloc]initWithContentViewController:[rollBarViewController standardRecommendNavi] leftMenuViewController:[LeftViewController new] rightMenuViewController:nil];
        _sideMenu.backgroundImage = [UIImage imageNamed:@"cebianlan"];
        // 使菜单出现时不显示状态栏
        _sideMenu.menuPrefersStatusBarHidden = YES;
        // 不予许菜单栏到了边缘还可以继续缩小
        _sideMenu.bouncesHorizontally = NO;
        
    }
    return _sideMenu;
}


- (void)showView
{
    UIImageView *view = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 578)];
    view.image = [UIImage imageNamed:@"04"];
    [self.window addSubview:view];
    view.alpha = 1.0;
    [UIView animateWithDuration:3.0f delay:2.0f options:UIViewAnimationOptionCurveLinear animations:^{
        view.alpha = 0.0;
    } completion:^(BOOL finished) {
        // 完成后执行code
        [NSThread sleepForTimeInterval:1.0f];
        [self.window removeFromSuperview];
    }];
}






@end




















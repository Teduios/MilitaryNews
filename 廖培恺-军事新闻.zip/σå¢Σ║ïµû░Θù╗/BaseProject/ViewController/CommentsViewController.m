//
//  CommentsViewController.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CommentsViewController.h"
#import "CommentsListViewModel.h"
#import "CommentsCell.h"

@interface CommentsViewController ()
@property(nonatomic,strong)CommentsListViewModel *moreCommentsVM;
@property(nonatomic, assign) NSInteger page;
@end

@implementation CommentsViewController

- (id)initWithAid:(NSString *)aid page:(NSInteger)page
{
    if (self = [super init]) {
        self.aid = aid;
        self.page = page;
    }
    return self;
}
- (id)init{
    if (self = [super init]) {
        NSAssert1(NO, @"%s 必须使用initWithAid方法初始化", __func__);
    }
    return self;
}
- (CommentsListViewModel *)moreCommentsVM
{
    if (!_moreCommentsVM) {
        _moreCommentsVM = [[CommentsListViewModel alloc]initWithAid:_aid page:_page];
    }
    return _moreCommentsVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[CommentsCell class] forCellReuseIdentifier:@"commentsCell"];
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.moreCommentsVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.moreCommentsVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView.footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.header beginRefreshing];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString *title1 = @"全部评论:";
    self.navigationItem.title = [title1 stringByAppendingString:[NSString stringWithFormat:@"%ld", [self.moreCommentsVM numberOfCommentsForList]]];
    
    return [self.moreCommentsVM numberOfCommentsForList];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    CommentsCell *commentsCell = [tableView dequeueReusableCellWithIdentifier:@"commentsCell" forIndexPath:indexPath];
    commentsCell.ipLb.text = [_moreCommentsVM ipForCommentsIndex:indexPath.row];
    commentsCell.dtimeLb.text = [_moreCommentsVM dtimeForCommentsIndex:indexPath.row];
    commentsCell.msgLb.text = [_moreCommentsVM msgForCommentsIndex:indexPath.row];
    commentsCell.selectionStyle = UITextBorderStyleNone;
    return commentsCell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str = [_moreCommentsVM msgForCommentsIndex:indexPath.row];
    UIFont *tfont = [UIFont systemFontOfSize:13];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:tfont,NSFontAttributeName, nil];
    CGSize sizeText = [str boundingRectWithSize:CGSizeMake(300, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
    return sizeText.height + 50;
}



@end

//
//  PicsViewController.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PicsViewController : UIViewController
/** 此界面内容要根据aid来决定，所以aid是必须的 */
- (id)initWithAid:(NSString *)aid type:(NSNumber *)type;
@property(nonatomic,strong) NSNumber *type;
@property(nonatomic,strong) NSString *aid;
@end

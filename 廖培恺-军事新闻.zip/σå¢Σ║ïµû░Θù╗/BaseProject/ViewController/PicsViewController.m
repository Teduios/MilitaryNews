//
//  PicsViewController.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicsViewController.h"
#import "iCarousel.h"
#import "PicsViewModel.h"
#import "PKImageView.h"
#import "Factory.h"

@interface PicsViewController ()<iCarouselDelegate,iCarouselDataSource>
@property(nonatomic,strong)PicsViewModel *picsVM;
@property(nonatomic,strong)iCarousel *ic;
@end

@implementation PicsViewController

- (id)initWithAid:(NSString *)aid type:(NSNumber *)type
{
    if (self = [super init]) {
        self.aid = aid;
        self.type = type;
    }
    return self;
}

- (id)init{
    if (self = [super init]) {
        NSAssert1(NO, @"%s 必须使用initWithAid方法初始化", __func__);
    }
    return self;
}

- (PicsViewModel *)picsVM
{
    if (!_picsVM) {
        _picsVM = [[PicsViewModel alloc]initWithAid:_aid type:_type.integerValue];
    }
    return _picsVM;
}

-(iCarousel *)ic
{
    if (!_ic) {
        _ic = [[iCarousel alloc]init];
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.type = 4;
        // 翻页模式
        _ic.pagingEnabled = YES;
        // 改变为竖向展示
//        _ic.vertical = YES;
        // 自动展示
//        _ic.autoscroll = YES;
    }
    return _ic;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 将图片显示到界面上
    self.ic.backgroundColor = [UIColor grayColor];
    [self.view addSubview:self.ic];
    
    [self.ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    [self.picsVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self.ic reloadData];
    }];
    [Factory addBackItemToVC:self];
    
    // 自动滚动
//    [NSTimer bk_scheduledTimerWithTimeInterval:2 block:^(NSTimer *timer) {
//        [self.ic scrollToItemAtIndex:self.ic.currentItemIndex + 1 animated:YES];
//    } repeats:YES];
}


#pragma mark ----iCarouselDelegate,iCarouselDataSource

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.picsVM.numberOfPicsForPics;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    if (!view) {
        NSInteger width = [self.picsVM widthForPics:index].integerValue;
        NSInteger height = [self.picsVM heightForPics:index].integerValue;
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, width, height)];
        
        PKImageView *imageView = [PKImageView new];
        imageView.tag = 100;
        [view addSubview:imageView];
        imageView.contentMode = UIViewContentModeScaleAspectFill;

        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    PKImageView *imageView = (PKImageView *)[view viewWithTag:100];
    [imageView.imageView setImageWithURL:[self.picsVM picURLForPics:index]];
    return view;
    
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index
{
    NSLog(@"点击了第%ld", (long)index);
}




@end

































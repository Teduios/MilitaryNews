//
//  recommendViewController.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface recommendViewController : UITableViewController
/** 接收外部传参，决定当前控制器显示哪种类型的信息 */
@property(nonatomic,strong) NSNumber *actType;
@property(nonatomic,strong)NSString *aid;
@property(nonatomic,strong)NSString *action;

@end

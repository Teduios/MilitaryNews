//
//  SettingViewController.m
//  BaseProject
//
//  Created by apple－jd15 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SettingViewController.h"
#import "Factory.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    self.title = @"个人设置";
    [Factory addMenuItemToVC:self];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:kRGBColor(120, 70, 18) cornerRadius:0.5] forBarMetrics:UIBarMetricsDefault];
}

+ (UINavigationController *)defaultNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        SettingViewController *vc = [SettingViewController new];
        navi = [[UINavigationController alloc] initWithRootViewController:vc];
    });
    return navi;
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.accessoryType = 1;
    
    cell.textLabel.text = @"字体大小";
    if (indexPath.row == 1) {
        cell.textLabel.text = @"夜间模式";
    }
    return cell;
}



@end

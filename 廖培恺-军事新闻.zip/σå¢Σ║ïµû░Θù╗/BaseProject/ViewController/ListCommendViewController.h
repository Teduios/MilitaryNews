//
//  ListCommendViewController.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface ListCommendViewController : UITableViewController
/** 此界面内容要根据aid来决定，所以aid是必须的 */
- (id)initWithAid:(NSString *)aid type:(NSNumber *)type;
@property(nonatomic,strong) NSNumber *type;
@property(nonatomic,strong) NSString *aid;
@property(nonatomic, assign) NSInteger page;
@end

//
//  recommendViewController.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "recommendViewController.h"
#import "recommendViewModel.h"
#import "ListRecommendViewModel.h"
#import "recommendCell.h"
#import "CommandingHeightCell.h"
#import "iCarousel.h"
#import "ImagePointCell.h"
#import "RecommendImagePointCell.h"
#import "ListCommendViewController.h"
#import "PicsViewController.h"


@interface recommendViewController ()<UITableViewDelegate,UITableViewDataSource,iCarouselDelegate,iCarouselDataSource>

@property(nonatomic,strong)recommendViewModel *recommendVM;
@property(nonatomic,strong)ListRecommendViewModel *listVM;

@end

@implementation recommendViewController
// 为滚动视图添加成员变量,因为不需要懒加载,所以不需要是属性
{
    iCarousel *_ic;
    UIPageControl *_pageControl;
    UILabel *_titleLb;
    NSTimer *_timer;
}

/** 添加头部滚动视图 */
- (UIView *)headerView
{
    [_timer invalidate];
    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, kWindowW/750*500)];
    // 添加底部视图
    UIView *botoomView = [UIView new];
    botoomView.backgroundColor = kRGBColor(240, 240, 240);
    [headView addSubview:botoomView];
    [botoomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.mas_equalTo(0);
        make.height.mas_equalTo(35);
    }];
    
    _titleLb = [UILabel new];
    _titleLb.font = [UIFont systemFontOfSize:15];
    //    _titleLb.numberOfLines = 0;
    [botoomView addSubview:_titleLb];
    [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.mas_equalTo(4);
        make.right.mas_equalTo(-10);
        make.left.mas_equalTo(45);
    }];
    
    _pageControl = [UIPageControl new];
    _pageControl.numberOfPages = self.recommendVM.indexSlideNumber;
    [botoomView addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.centerY.mas_equalTo(11);
        make.width.mas_lessThanOrEqualTo(60);
        make.width.mas_greaterThanOrEqualTo(20);
        make.left.mas_equalTo(_titleLb.mas_right).mas_equalTo(-10);
    }];
    _titleLb.text = [self.recommendVM titleForRowInSlide:0];
    // 添加滚动栏
    _ic = [iCarousel new];
    [headView addSubview:_ic];
    [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_equalTo(0);
        make.bottom.mas_equalTo(botoomView.mas_top).mas_equalTo(0);
    }];
    _ic.delegate = self;
    _ic.dataSource = self;
    _ic.pagingEnabled = YES;
    _ic.scrollSpeed = 1;
    //如果只有一张图,则不显示圆点
    _pageControl.hidesForSinglePage = YES;
    //如果只有一张图,则不可以滚动
    _ic.scrollEnabled = self.recommendVM.indexSlideNumber != 1;
    _pageControl.pageIndicatorTintColor = [UIColor brownColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor grayColor];
    
    if (self.recommendVM.indexSlideNumber > 1) {
        _timer = [NSTimer bk_scheduledTimerWithTimeInterval:4 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex + 1 animated:YES];
        } repeats:YES];
    }
    //小圆点 不能与用户交互
    _pageControl.userInteractionEnabled = NO;
    return headView;
}


- (recommendViewModel *)recommendVM
{
    if (!_recommendVM) {
        _recommendVM = [[recommendViewModel alloc]initWithType:_actType.integerValue];
    }
    return _recommendVM;
}
- (ListRecommendViewModel *)listVM
{
    if (!_listVM) {
        _listVM = [[ListRecommendViewModel alloc]initWithAid:_aid type:_actType.integerValue];
    }
    return _listVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[recommendCell class] forCellReuseIdentifier:@"recomendCell"];
    [self.tableView registerClass:[CommandingHeightCell class] forCellReuseIdentifier:@"cHeightCell"]; // 制高点页面
    [self.tableView registerClass:[ImagePointCell class] forCellReuseIdentifier:@"imagePointCell"];
    [self.tableView registerClass:[RecommendImagePointCell class] forCellReuseIdentifier:@"rpCell"]; // 推荐页面的大视野cell
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.recommendVM refreshDataCompletionHandle:^(NSError *error) {
            if (_actType.intValue == 0) {
                self.tableView.tableHeaderView = [self headerView];
            }
            [self.tableView.header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.recommendVM getMoreDataCompletionHandle:^(NSError *error) {
            if (_actType.intValue == 0) {
                self.tableView.tableHeaderView = [self headerView];
            }
            [self.tableView.footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.header beginRefreshing];
}


#pragma mark - Table view data source

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (_actType.intValue == 2) {
        PicsViewController *vc = [[PicsViewController alloc]initWithAid:[self.recommendVM aidInListForRow:indexPath.row] type:_actType];
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        ListCommendViewController *vc = [[ListCommendViewController alloc]initWithAid:[self.recommendVM aidInListForRow:indexPath.row] type:_actType];
        [self.navigationController pushViewController:vc animated:YES];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.recommendVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_actType.intValue == 0) { // 推荐页面(参合着其他页面的一些cell)
      if ([self.recommendVM numberOfNav:_actType.intValue]){
            // 图片控
            ImagePointCell *cell = [tableView dequeueReusableCellWithIdentifier:@"imagePointCell" forIndexPath:indexPath];
            [cell.image_arr[0].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:0]];
            [cell.image_arr[1].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:1]];
            [cell.image_arr[2].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:2]];
            
            cell.titleLb.text = [self.recommendVM titleForRowInList:indexPath.row];
            cell.pubDataLb.text = [self.recommendVM pubDataForRowInList:indexPath.row];
            cell.plLb.text = [[self.recommendVM plForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 评论"]];
            cell.diggLb.text = [[self.recommendVM diggForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 赞"]];
            return cell;
        }else if ([self.recommendVM numberOfNav:_actType.intValue]){
            // 大视野
            RecommendImagePointCell *cell = [tableView dequeueReusableCellWithIdentifier:@"rpCell" forIndexPath:indexPath];
            
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 20)];
            label.text = @"大视野";
            label.font = [UIFont systemFontOfSize:13];
            label.textColor = [UIColor grayColor];
            [cell addSubview:label];
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(10);
                make.top.mas_equalTo(0);
            }];
            
            [cell.image_arr[0].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:0]];
            [cell.image_arr[1].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:1]];
            [cell.image_arr[2].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:2]];
            
            cell.titleLb.text = [self.recommendVM titleForRowInList:indexPath.row];
            cell.pubDataLb.text = [self.recommendVM pubDataForRowInList:indexPath.row];
            cell.plLb.text = [[self.recommendVM plForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 评论"]];
            cell.diggLb.text = [[self.recommendVM diggForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 赞"]];
            return cell;
        }else{
            // 普通的cell
            recommendCell *cell = [tableView dequeueReusableCellWithIdentifier:@"recomendCell" forIndexPath:indexPath];
            [cell.imageV.imageView setImageWithURL:[self.recommendVM imageURLForRowInList:indexPath.row]];
            cell.titleLb.text = [self.recommendVM titleForRowInList:indexPath.row];
            cell.pubDataLb.text = [self.recommendVM pubDataForRowInList:indexPath.row];
            cell.plLb.text = [[self.recommendVM plForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 评论"]];
            cell.diggLb.text = [[self.recommendVM diggForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 赞"]];
            return cell;
        }
        
        
    }else if (_actType.intValue == 3 || _actType.intValue == 4){ // 大视野,读点史
        recommendCell *cell = [tableView dequeueReusableCellWithIdentifier:@"recomendCell" forIndexPath:indexPath];
        [cell.imageV.imageView setImageWithURL:[self.recommendVM imageURLForRowInList:indexPath.row]];
        cell.titleLb.text = [self.recommendVM titleForRowInList:indexPath.row];
        cell.pubDataLb.text = [self.recommendVM pubDataForRowInList:indexPath.row];
        cell.plLb.text = [[self.recommendVM plForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 评论"]];
        cell.diggLb.text = [[self.recommendVM diggForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 赞"]];
        return cell;
        
    }else if (_actType.intValue == 1 || _actType.intValue == 5){ // 制高点,流媒体
        CommandingHeightCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cHeightCell" forIndexPath:indexPath];
        
        if (_actType.intValue == 5) { // 添加播放按钮
            UIButton *imageBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 45, 44)];
            [imageBtn setImage:[UIImage imageNamed:@"play"] forState:0];
            [cell.imageV.imageView addSubview:imageBtn];
            [imageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(0);
            }];
        }
        
        [cell.imageV.imageView setImageWithURL:[self.recommendVM imageURLForRowInList:indexPath.row]];
        cell.titleLb.text = [self.recommendVM titleForRowInList:indexPath.row];
        cell.pubDataLb.text = [self.recommendVM pubDataForRowInList:indexPath.row];
        cell.plLb.text = [[self.recommendVM plForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 评论"]];
        cell.diggLb.text = [[self.recommendVM diggForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 赞"]];
        return cell;
        
    }else if (_actType.intValue == 2){ // 图片控
        ImagePointCell *cell = [tableView dequeueReusableCellWithIdentifier:@"imagePointCell" forIndexPath:indexPath];
        [cell.image_arr[0].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:0]];
        [cell.image_arr[1].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:1]];
        [cell.image_arr[2].imageView setImageWithURL:[self.recommendVM imageArrURLForRowInList:indexPath.row imageIndex:2]];
        
        cell.titleLb.text = [self.recommendVM titleForRowInList:indexPath.row];
        cell.pubDataLb.text = [self.recommendVM pubDataForRowInList:indexPath.row];
        cell.plLb.text = [[self.recommendVM plForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 评论"]];
        cell.diggLb.text = [[self.recommendVM diggForRowInList:indexPath.row]stringByAppendingString:[NSString stringWithFormat:@" 赞"]];
        return cell;
        
    }
    return nil;
}

/** 去掉分割线左侧缝隙 */
kRemoveCellSeparator

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_actType.intValue == 0) {
        if ([self.recommendVM numberOfNav:_actType.intValue]){
            // 图片控
            return 225;
        }else if ([self.recommendVM numberOfNav:_actType.intValue]){
            // 大视野
            return 150;
        }else{
            return 100;
        }
    }else if (_actType.intValue == 3 || _actType.intValue == 4){
        return 100;
    }else if (_actType.intValue == 1 || _actType.intValue == 5 || _actType.intValue == 2){
        return 225;
    }
    return 0;
}




#pragma mark -iCarouselDataSource,iCarouselDelegate

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.recommendVM.indexSlideNumber;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    if (!view) {
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/750*500 - 35)];
        UIImageView *imageView = [UIImageView new];
        [view addSubview:imageView];
        imageView.tag = 100;
        imageView.contentMode = 2;
        view.clipsToBounds = YES;
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    [imageView setImageWithURL:[self.recommendVM imageURLForRowInSlide:index]];
    
    return view;
}

/** 允许循环滚动 */
- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    return value;
}

/** 监控当前滚动到第几个 */
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel
{
    _titleLb.text = [self.recommendVM titleForRowInSlide:carousel.currentItemIndex];
    _pageControl.currentPage = carousel.currentItemIndex;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index
{
    ListCommendViewController *vc1 = [[ListCommendViewController alloc]initWithAid:[self.recommendVM aidInSlideForRow: index] type:_actType];
    [self.navigationController pushViewController:vc1 animated:YES];
}







@end













































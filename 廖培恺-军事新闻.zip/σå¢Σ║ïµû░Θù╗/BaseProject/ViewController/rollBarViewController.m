//
//  rollBarViewController.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "rollBarViewController.h"
#import "recommendViewController.h"
#import "Factory.h"

@interface rollBarViewController ()

@end

@implementation rollBarViewController

+ (UINavigationController *)standardRecommendNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        rollBarViewController *vc = [[rollBarViewController alloc]initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        // 例如设置第一个控制器的某个属性值, KVC
        // vc setValue:[values[0] forKey:key[0];
        vc.keys = [self vcKeys];
        vc.values = [self vcValues];
        
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}
/** 提供每个vc对应的values值数组 */
+ (NSArray *)vcValues
{
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < [self itemNames].count; i ++ ) {
        // 数值上,vc的itemNames的枚举值, 插好和i值相同
        [arr addObject:@(i)];
    }
    return arr;
}

+ (NSArray *)vcKeys
{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:@"actType"];
    }
    return [arr copy];
}

+ (NSArray *)viewControllerClasses
{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:[recommendViewController class]];
    }
    return [arr copy];
}

+ (NSArray *)itemNames
{
    return @[@"推荐", @"制高点", @"图片控", @"大视野", @"读点史", @"流媒体"];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.title = @"全球军情资讯";
    // 导航栏按钮设置
    [Factory addMenuItemToVC:self];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:kRGBColor(240, 250, 248) cornerRadius:0.5] forBarMetrics:UIBarMetricsDefault];
}



@end


















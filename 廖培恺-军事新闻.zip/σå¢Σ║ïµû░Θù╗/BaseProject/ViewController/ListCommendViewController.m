//
//  ListCommendViewController.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//  自定义详情页

#import "ListCommendViewController.h"
#import "ListRecommendViewModel.h"
#import "ActionViewModel.h"
#import "SendCommentsViewModel.h"
#import "VideoViewModel.h"
#import "TitleCell.h"
#import "ListImageCell.h"
#import "ContentsCell.h"
#import "ShareCell.h"
#import "CommentsCell.h"
#import "AddMoreCommentsCell.h"
#import "VideoCell.h"
#import "CommentsViewController.h"
#import "VideoViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

@interface ListCommendViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)ListRecommendViewModel *listVM;
@property(nonatomic,strong)ActionViewModel *actionVM;
@property(nonatomic,strong)SendCommentsViewModel *sendVM;
@property(nonatomic,strong)VideoViewModel *videoVM;
@property(nonatomic,strong)NSString *action;
@property(nonatomic,strong)ShareCell *tempCell;

@property(nonatomic,strong)NSString *msg;
@property(nonatomic,strong)NSString *username;
@property(nonatomic,strong)UITextField *textF;
@end

@implementation ListCommendViewController
{
    NSInteger _numberOfPic;
    NSInteger _numberOfcontent;
}

- (SendCommentsViewModel *)sendVM
{
    if (!_sendVM) {
        _sendVM = [[SendCommentsViewModel alloc]initSendCommentsWithMsg:_msg aid:_aid username:_username];
    }
    return _sendVM;
}

- (ListRecommendViewModel *)listVM
{
    if (!_listVM) {
        _listVM = [[ListRecommendViewModel alloc]initWithAid:_aid type:_type.integerValue];
    }
    return _listVM;
}

- (ActionViewModel *)actionVM
{
    if (!_actionVM) {
        _actionVM = [[ActionViewModel alloc]initWithID:_aid action:_action];
    }
    return _actionVM;
}
/** 流媒体 */
- (VideoViewModel *)videoVM
{
    if (!_videoVM) {
        _videoVM = [[VideoViewModel alloc]initWithAid:_aid type:_type.integerValue];
    }
    return _videoVM;
}


- (id)initWithAid:(NSString *)aid type:(NSNumber *)type
{
    if (self = [super init]) {
        self.aid = aid;
        self.type = type;
    }
    return self;
}

- (id)init{
    if (self = [super init]) {
        NSAssert1(NO, @"%s 必须使用initWithAid方法初始化", __func__);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[TitleCell class] forCellReuseIdentifier:@"titleCell"];
    [self.tableView registerClass:[ListImageCell class] forCellReuseIdentifier:@"listImageCell"];
    [self.tableView registerClass:[ContentsCell class] forCellReuseIdentifier:@"contentsCell"];
    [self.tableView registerClass:[ShareCell class] forCellReuseIdentifier:@"shareCell"];
    [self.tableView registerClass:[CommentsCell class] forCellReuseIdentifier:@"commentsCell"];
    [self.tableView registerClass:[AddMoreCommentsCell class] forCellReuseIdentifier:@"addCommentsCell"];
    [self.tableView registerClass:[VideoCell class] forCellReuseIdentifier:@"videoCell"];
    
    [self.listVM getDataFromNetCompleteHandle:^(NSError *error) {
        _numberOfPic = [self.listVM numberOfPicsURLForList];
        _numberOfcontent = [self.listVM numberOfContentsForList]-1;
        [self.tableView reloadData];
    }];
    
    [self.videoVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self.tableView reloadData];
    }];
    
    // 触摸事件
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide:)];
    // 设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    // 将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
}

/**
 * 点击空白处回收键盘
 */
-(void)keyboardHide:(UITapGestureRecognizer*)tap{
    [_textF resignFirstResponder];
}

#pragma mark ----UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) { // 标题分区
        return 1;
    }else if (section == 1){ // 图文混排
        if (_type.intValue == 5) {
            return 1;
        }else{
            return _numberOfPic + _numberOfcontent;
        }
    }else if (section == 2) { // 分享
        return 1;
    }else if (section == 3){ // 评论
        if ([self.listVM numberOfCommentsForList] >= 2) {
            return 2;
        }else{
            return [self.listVM numberOfCommentsForList];
        }
    }else if (section == 4){ // 加载更多评论
        return 1;
    }else{
        return 1;
    }
}
/** 去掉分割线左侧缝隙 */
//kRemoveCellSeparator

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    // 标题分区
    if (indexPath.section == 0) {
        TitleCell *cell = [tableView dequeueReusableCellWithIdentifier:@"titleCell" forIndexPath:indexPath];
        cell.titleLb.text = [_listVM titleForList];
        cell.pubDataLb.text = [_listVM pubDataForList];
        cell.authorLb.text = [_listVM authorForList];
        cell.clickLb.text = [[_listVM clickForList]stringByAppendingString:[NSString stringWithFormat:@" 阅读"]];
        cell.selectionStyle = UITextBorderStyleNone;
        return cell;
        // 图文混排分区
    }else if (indexPath.section == 1){
        if (_type.intValue == 5) { // 播放流媒体
            VideoCell *videoCell = [tableView dequeueReusableCellWithIdentifier:@"videoCell" forIndexPath:indexPath];
            [videoCell.videophotoLb.imageView setImageWithURL:[self.videoVM videophoto]];
            
            UIButton *imageBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 45, 44)];
            [imageBtn setImage:[UIImage imageNamed:@"play"] forState:0];
            [videoCell.videophotoLb.imageView addSubview:imageBtn];
            [imageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(0);
            }];
//            [imageBtn addTarget:self action:@selector(play) forControlEvents:UIControlEventTouchUpInside];
            
            return videoCell;
        }
        if ((indexPath.row)%2 == 0) { // 图片
            ListImageCell *listCell = [tableView
                                       dequeueReusableCellWithIdentifier:@"listImageCell" forIndexPath:indexPath];
            if (indexPath.row > 0) {
                [listCell.picV.imageView setImageWithURL:[self.listVM picURLForListIndex:indexPath.row/2]];
            }else{
                [listCell.picV.imageView setImageWithURL:[self.listVM picURLForListIndex:indexPath.row]];}
            listCell.selectionStyle = UITextBorderStyleNone;
            return listCell;
        }else{ // 文字
            ContentsCell *contentsCell = [tableView dequeueReusableCellWithIdentifier:@"contentsCell" forIndexPath:indexPath];
            if (indexPath.row > 1) {
                contentsCell.contentsLb.text = [_listVM contentsForListIndex:(indexPath.row+1)/2];
            }else{
                contentsCell.contentsLb.text = [_listVM contentsForListIndex:indexPath.row];
            }
            contentsCell.selectionStyle = UITextBorderStyleNone;
            return contentsCell;
        }
        // 分享分区
    }else if (indexPath.section == 2){
        ShareCell *shareCell = [tableView dequeueReusableCellWithIdentifier:@"shareCell" forIndexPath:indexPath];
        _tempCell = shareCell;
        shareCell.selectionStyle = UITextBorderStyleNone;
        
        [shareCell.goodpostBtn setTitle:[self.listVM goodpostForList] forState:0];
        [shareCell.bagpostBtn setTitle:[self.listVM bagpostForList] forState:0];
        
        [shareCell.goodpostBtn addTarget:self action:@selector(goodAction) forControlEvents:UIControlEventTouchUpInside];
        [shareCell.bagpostBtn addTarget:self action:@selector(bagAction) forControlEvents:UIControlEventTouchUpInside];
        
        shareCell.title = [self.listVM titleForList];
        shareCell.pageUrl = [self.listVM HTMLForListIndex];
        
        if ([self.listVM numberOfCommentsForList] > 0) {
            shareCell.commentLb.text = @"精彩评论:";
        }else{
            shareCell.commentLb.text = @"暂无评论:";
        }
        return shareCell;
        // 评论分区
    }else if (indexPath.section == 3){
        CommentsCell *commentsCell = [tableView dequeueReusableCellWithIdentifier:@"commentsCell" forIndexPath:indexPath];
        commentsCell.ipLb.text = [_listVM ipForCommentsIndex:indexPath.row];
        commentsCell.dtimeLb.text = [_listVM dtimeForCommentsIndex:indexPath.row];
        commentsCell.msgLb.text = [_listVM msgForCommentsIndex:indexPath.row];
        commentsCell.selectionStyle = UITextBorderStyleNone;
        return commentsCell;
    }else if (indexPath.section == 4){
        AddMoreCommentsCell *addCommentsCell = [tableView dequeueReusableCellWithIdentifier:@"addCommentsCell" forIndexPath:indexPath];
        addCommentsCell.moreCommentsLb.text = @"点击查看更多评论...";
        if ([self.listVM numberOfCommentsForList] < 2) {
            addCommentsCell.moreCommentsLb.text = @"";
            addCommentsCell.selectionStyle = UITextBorderStyleNone;
        }
        return addCommentsCell;
    }
    return nil;
}

/**
 * 设置cell的高度
 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) { // 标题
        NSString *str = [_listVM titleForList];
        UIFont *tfont = [UIFont systemFontOfSize:17];
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:tfont,NSFontAttributeName, nil];
        CGSize sizeText = [str boundingRectWithSize:CGSizeMake(300, 200) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
        return sizeText.height + 25;
    }else if (indexPath.section == 1){ // 图文混排
        if (indexPath.row%2 == 0) {
            return 200;
        }else{
            if (indexPath.row > 1) {
                NSString *str = [_listVM contentsForListIndex:(indexPath.row+1)/2];
                UIFont *tfont = [UIFont systemFontOfSize:14];
                NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:tfont,NSFontAttributeName, nil];
                CGSize sizeText = [str boundingRectWithSize:CGSizeMake(300, 1500) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
                return sizeText.height+10;
            }else{
                NSString *str = [_listVM contentsForListIndex:indexPath.row];
                UIFont *tfont = [UIFont systemFontOfSize:14];
                NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:tfont,NSFontAttributeName, nil];
                CGSize sizeText = [str boundingRectWithSize:CGSizeMake(300, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
                return sizeText.height+10;
            }
        }
    }else if (indexPath.section == 2){ // 分享
        return 130;
    }else if (indexPath.section == 3){ // 评论
        NSString *str = [_listVM msgForCommentsIndex:indexPath.row];
        UIFont *tfont = [UIFont systemFontOfSize:13];
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:tfont,NSFontAttributeName, nil];
        CGSize sizeText = [str boundingRectWithSize:CGSizeMake(300, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
        return sizeText.height + 30;
    }else if (indexPath.section == 4){
        return 30;
    }else{
        return 10;
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 4) {
        CommentsViewController *vc = [[CommentsViewController alloc]initWithAid:_aid page:_page];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if (indexPath.section == 1 && _type.intValue == 5){
        VideoViewController *vc = [[VideoViewController alloc]initWithURL:[self.videoVM videoplay]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}



/**
 *  创建评论输入框
 */
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *footer = [[UIView alloc]init];
    [footer setBackgroundColor:[UIColor grayColor]];
    
    UITextField *textField = [[UITextField alloc]init];
    _textF = textField;
    [textField setFrame:CGRectMake(0, 0, 255, 25)];
    textField.borderStyle = 3;
    [textField setPlaceholder:@" 我来说两句..."];
    textField.font = [UIFont systemFontOfSize:13];
    [footer addSubview:textField];
    
    UIButton *btn = [UIButton buttonWithType:1];
    [btn setTitle:@"发送" forState:0];
    [btn addTarget:self action:@selector(send) forControlEvents:UIControlEventTouchUpInside];
    [footer addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.left.mas_equalTo(270);
        make.top.mas_equalTo(5);
        make.bottom.mas_equalTo(-5);
    }];
    return footer;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 2) {
        return 25;
    }
    return 0;
}
/*
 * 点击发送按钮触发
 */
- (void)send
{
    _username = @"";
    _msg = _textF.text;
    [self.sendVM getDataFromNetCompleteHandle:^(NSError *error) {
        
    }];
    _textF.text = @"";
    [_textF resignFirstResponder];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(137, 0, 66, 25)];
    label.text = @"已发送...";
    label.textColor = kRGBColor(58, 164, 238);
    label.font = [UIFont systemFontOfSize:15];
    [_textF addSubview:label];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(),^{
        [label removeFromSuperview];
    });
}

/*
 * 点击支持按钮触发
 */
- (void)goodAction
{
    _action = @"good";
    [self.actionVM getDataFromNetCompleteHandle:^(NSError *error) {
        if ([self.actionVM goodpostForAction] != 0) {
            [_tempCell.goodpostBtn setTitle:[NSString stringWithFormat:@"%ld", (long)[self.actionVM goodpostForAction]] forState:0];
        }else{
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 55, 180, 80)];
            label.text = @"您之前已表决...";
            label.textColor = [UIColor grayColor];
            label.font = [UIFont systemFontOfSize:12];
            [_tempCell addSubview:label];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(),^{
                [label removeFromSuperview];
            });
        }
    }];
}

/*
 * 点击反对按钮触发
 */
- (void)bagAction
{
    _action = @"bad";
    [self.actionVM getDataFromNetCompleteHandle:^(NSError *error) {
        if ([self.actionVM bagpostForAction] != 0) {
            [_tempCell.bagpostBtn setTitle:[self.actionVM bagpostForAction] forState:0];
        }else{
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 55, 180, 80)];
            label.text = @"您之前已表决...";
            label.textColor = [UIColor grayColor];
            label.font = [UIFont systemFontOfSize:12];
            label.numberOfLines = 0;
            [_tempCell addSubview:label];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(),^{
                [label removeFromSuperview];
            });
        }
    }];
}

////为了保证同一时间只有一个播放器，使用单例模式
//+ (AVPlayerViewController *)sharedInstance{
//    static AVPlayerViewController *vc = nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        vc = [AVPlayerViewController new];
//    });
//    return vc;
//}
//
//- (void)play
//{
//    AVPlayer *player = [AVPlayer playerWithURL:[NSURL URLWithString:[self.videoVM videoplay]]];
//    [player play];
//    [ListCommendViewController sharedInstance].player = player;
//    [self.tableView addSubview:[ListCommendViewController sharedInstance].view];
//    [[ListCommendViewController sharedInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(0);
//    }];
//}







@end


























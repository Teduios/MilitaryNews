//
//  VideoViewController.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Liaopeikai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoViewController : UIViewController

- initWithURL:(NSString *)url;
@property(nonatomic,strong)NSString *url;

@end

//
//  VideoViewController.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Liaopeikai. All rights reserved.
//

#import "VideoViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

@interface VideoViewController ()
// 视频播放器
@property(nonatomic,strong)AVPlayer *player;
// 把视频显示在屏幕上,需要一个layer
@property(nonatomic,strong)AVPlayerLayer *layer;
@end


@implementation VideoViewController

- (id)initWithURL:(NSString *)url
{
    if (self = [super init]) {
        self.url = url;
        NSLog(@"----url:%@-------------", _url);
    }
    return self;
}
// 为了保证只有一个播放器,使用单例
//+ (AVPlayerViewController *)sharedInstance{
//    static AVPlayerViewController *vc = nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        vc = [AVPlayerViewController new];
//    });
//    return vc;
//}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
//    _url = [_url stringByAppendingString:[NSString stringWithFormat:@"mp4"]];
    
    AVPlayerViewController *vc=[AVPlayerViewController new];
    vc.player=[AVPlayer playerWithURL:[NSURL URLWithString:_url]];
    [self presentViewController:vc animated:YES completion:nil];
    
    [self.player play];
    
}


@end

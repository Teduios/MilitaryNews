//
//  VideoViewModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "recommendNetManager.h"

@interface VideoViewModel : BaseViewModel
- (id)initWithAid:(NSString *)aid type:(ActType)type;
@property(nonatomic,strong)NSString *aid;
@property(nonatomic) ActType type;

@property(nonatomic,strong)VideoModel *videoModel;

/** 提示点击的视频图片 */
- (NSURL *)videophoto;
/** 视频播放地址 */
- (NSString *)videoplay;
/** 返回列表中某行数据题目 */
- (NSString *)title;
/** 返回列表中某行资讯发布的日期 */
- (NSString *)pubData;
/** 返回列表中某行评论数 */
- (NSString *)comments;
/** 返回列表中某行点赞数 */
- (NSString *)goodpost;

@end

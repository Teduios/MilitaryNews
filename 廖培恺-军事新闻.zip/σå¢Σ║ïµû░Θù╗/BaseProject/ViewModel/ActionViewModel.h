//
//  ActionViewModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "recommendNetManager.h"

@interface ActionViewModel : BaseViewModel
- (id)initWithID:(NSString *)ID action:(NSString *)action;
@property(nonatomic,strong)NSString *ID;
@property(nonatomic,strong)NSString *action;

@property(nonatomic,strong) ActionModel *actionModel;

/** 支持数 */
- (NSInteger)goodpostForAction;
/** 反对数 */
- (NSString *)bagpostForAction;



@end

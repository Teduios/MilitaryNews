//
//  recommendViewModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "recommendViewModel.h"

@implementation recommendViewModel

- (instancetype)initWithType:(ActType)type{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}
// 预防性编程，防止没有使用initWithType初始化
- (id)init{
    if (self = [super init]) {
        // 如果使用此方法初始化，那么崩溃提示
        NSAssert1(NO, @"%s 必须使用initWithType初始化", __func__);
    }
    return self;
}
// 开始刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
// 加载更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
// 获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [recommendNetManager getRecommendWithType:_type page:_page completionHandle:^(recommendModel *model, NSError *error) {
        if (_page == 1) {
            self.rModel = model;
            [self.dataArr removeAllObjects];
            self.indexSlideArr = nil;
        }
        self.rModel = model;
        [self.dataArr addObjectsFromArray:model.data.item];
        self.indexSlideArr = model.data.slide;
        completionHandle(error);
    }];
}

- (NSInteger)rowNumber
{
    return self.dataArr.count;
}

#pragma mark -------详情页

/** 返回某行数据的aid */
- (NSString *)aidInListForRow:(NSInteger)row
{
    return [self modelForArr:self.dataArr row:row].aid;
}
/** 返回滚动栏的aid */
- (NSString *)aidInSlideForRow:(NSInteger)row
{
    return [self slideModelForArr:self.indexSlideArr row:row].aid;
}


/** 用于获取模型List中的属性 以便与网络请求下来的数据对接 */
- (recommendItemModel *)modelForArr:(NSArray *)arr row:(NSInteger)row
{
    return arr[row];
}
/** 用于获取模型(展示滚动栏)Slide中的属性 以便与网络请求下来的数据对接 */
- (recommendSlideModel *)slideModelForArr:(NSArray *)arr row:(NSInteger)row
{
    return arr[row];
}

/** 返回列表中某行数据的图片 */
- (NSURL *)imageURLForRowInList:(NSInteger)row
{
    return [NSURL URLWithString:[self modelForArr:self.dataArr row:row].image];
}
/** 返回列表中某行数据的图片数组 */
- (NSURL *)imageArrURLForRowInList:(NSInteger)row imageIndex:(NSInteger)imageIndex
{
    return [NSURL URLWithString:[self modelForArr:self.dataArr row:row].image_arr[imageIndex]];
}
/** 返回列表中某行数据题目 */
- (NSString *)titleForRowInList:(NSInteger)row
{
    return [self modelForArr:self.dataArr row:row].title;
}
/** 返回列表中某行资讯发布的日期 */
- (NSString *)pubDataForRowInList:(NSInteger)row
{
    return [self modelForArr:self.dataArr row:row].pubDate;
}
/** 返回列表中某行评论数 */
- (NSString *)plForRowInList:(NSInteger)row
{
    return [self modelForArr:self.dataArr row:row].pl;
}
/** 返回列表中某行点赞数 */
- (NSString *)diggForRowInList:(NSInteger)row
{
    return [self modelForArr:self.dataArr row:row].digg;
}
#pragma mark -------滚动展示栏

/** 滚动栏的图片数量 */
- (NSInteger)indexSlideNumber
{
    return self.indexSlideArr.count;
}

/** 滚动展示栏的图片 */
- (NSURL *)imageURLForRowInSlide:(NSInteger)row
{
    return [NSURL URLWithString:[self slideModelForArr:self.indexSlideArr row:row].image];
}
/** 滚动栏展示的文字 */
- (NSString *)titleForRowInSlide:(NSInteger)row
{
    return [self slideModelForArr:self.indexSlideArr row:row].title;
}


/** 返回推荐cell中特殊的cell */
- (BOOL)numberOfNav:(NSInteger)row
{
    if (row == 2 || row == 3) {
        return YES;
    }
    return NO;
}
- (recommendModel *)rModel
{
    if (!_rModel) {
        _rModel = [[recommendModel alloc]init];
    }
    return _rModel;
}




















@end

































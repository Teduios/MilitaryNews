//
//  VideoViewModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewModel.h"

@implementation VideoViewModel

- (id)initWithAid:(NSString *)aid type:(ActType)type
{
    if (self = [super init]) {
        self.aid = aid;
        self.type = type;
    }
    return self;
}

/** 防御性编程，不允许使用init初始化 */
- (id)init{
    if (self = [super init]) {
        //%s->__func__  会显示 哪个类中的哪个方法
        NSAssert1(NO, @"%s 必须使用initWithAid初始化", __func__);
    }
    return self;
}


- (VideoModel *)videoModel
{
    if (!_videoModel) {
        _videoModel = [[VideoModel alloc]init];
    }
    return _videoModel;
}


- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [recommendNetManager getVideoDetailRecommendWithAid:_aid type:_type completionHandle:^(VideoModel *model, NSError *error) {
        self.videoModel = model;
        completionHandle(error);
    }];
}


/** 提示点击的视频图片 */
- (NSURL *)videophoto
{
    NSURL *url = [NSURL URLWithString:self.videoModel.data.video_photo];
    return url;
}
/** 视频播放地址 */
- (NSString *)videoplay
{
    return self.videoModel.data.video_play;
}
/** 返回列表中某行数据题目 */
- (NSString *)title
{
    return self.videoModel.data.title;
}
/** 返回列表中某行资讯发布的日期 */
- (NSString *)pubData
{
    return self.videoModel.data.pubDate;
}
/** 返回列表中某行评论数 */
- (NSString *)comments
{
    return self.videoModel.data.comments.count;
}
/** 返回列表中某行点赞数 */
- (NSString *)goodpost
{
    return self.videoModel.data.goodpost;
}



@end














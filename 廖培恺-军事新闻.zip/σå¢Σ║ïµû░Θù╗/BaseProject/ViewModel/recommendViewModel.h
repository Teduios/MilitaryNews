//
//  recommendViewModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "recommendNetManager.h"

@interface recommendViewModel : BaseViewModel
/** 必须使用此初始化方法，需要一个类型 */
- (instancetype)initWithType:(ActType)type;
@property(nonatomic) ActType type;

/** 返回当前行数 */
@property(nonatomic) NSInteger rowNumber;
/** 页数 */
@property(nonatomic, assign) NSInteger page;
/** 返回列表中某行数据的图片 */
- (NSURL *)imageURLForRowInList:(NSInteger)row;
/** 返回列表中某行数据的图片数组 */
- (NSURL *)imageArrURLForRowInList:(NSInteger)row imageIndex:(NSInteger)imageIndex;
/** 返回列表中某行数据题目 */
- (NSString *)titleForRowInList:(NSInteger)row;
/** 返回列表中某行资讯发布的日期 */
- (NSString *)pubDataForRowInList:(NSInteger)row;
/** 返回列表中某行评论数 */
- (NSString *)plForRowInList:(NSInteger)row;
/** 返回列表中某行点赞数 */
- (NSString *)diggForRowInList:(NSInteger)row;


/** 滚动展示栏的图片 */
- (NSURL *)imageURLForRowInSlide:(NSInteger)row;
/** 滚动栏展示的文字 */
- (NSString *)titleForRowInSlide:(NSInteger)row;
/** 滚动栏的图片数量 */
@property(nonatomic, assign) NSInteger indexSlideNumber;
/** 存放头部滚动 */
@property(nonatomic,strong)NSArray *indexSlideArr;

#pragma mark -详情页

/** 返回某行数据的aid */
- (NSString *)aidInListForRow:(NSInteger)row;
/** 返回滚动栏的aid */
- (NSString *)aidInSlideForRow:(NSInteger)row;


/** 返回推荐cell中特殊的cell */
- (BOOL)numberOfNav:(NSInteger)row;
@property(nonatomic,strong)recommendModel *rModel;



@end






























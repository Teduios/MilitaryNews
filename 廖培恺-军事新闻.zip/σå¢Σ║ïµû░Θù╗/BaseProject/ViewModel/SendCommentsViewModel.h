//
//  SendCommentsViewModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "recommendNetManager.h"

@interface SendCommentsViewModel : BaseViewModel
- initSendCommentsWithMsg:(NSString *)msg aid:(NSString *)aid username:(NSString *)username;
@property(nonatomic,strong)NSString *msg;
@property(nonatomic,strong)NSString *aid;
@property(nonatomic,strong)NSString *username;

/** 评论内容 */
- (NSString *)msgForComments:(NSInteger)row;
/** 评论者名称 */
- (NSString *)usernameForComments:(NSInteger)row;

@end

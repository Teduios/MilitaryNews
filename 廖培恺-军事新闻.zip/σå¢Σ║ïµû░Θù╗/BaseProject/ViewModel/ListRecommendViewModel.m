//
//  ListRecommendViewModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ListRecommendViewModel.h"

@implementation ListRecommendViewModel

- (id)initWithAid:(NSString *)aid type:(ActType)type
{
    if (self = [super init]) {
        self.aid = aid;
        self.type = type;
    }
    return self;
}

/** 防御性编程，不允许使用init初始化 */
- (id)init{
    if (self = [super init]) {
        //%s->__func__  会显示 哪个类中的哪个方法
        NSAssert1(NO, @"%s 必须使用initWithAid初始化", __func__);
    }
    return self;
}

- (ListRecommendModel *)listModel
{
    if (!_listModel) {
        _listModel = [[ListRecommendModel alloc]init];
    }
    return _listModel;
}


- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [recommendNetManager getListDetailRecommendWithAid:_aid type:_type completionHandle:^(ListRecommendModel *model, NSError *error) {
        self.listModel = model;
        completionHandle(error);
    }];
}

/** 返回列表中某行数据题目 */
- (NSString *)titleForList
{
    return self.listModel.data.title;
}
/** 发布的日期 */
- (NSString *)pubDataForList
{
    return self.listModel.data.pubDate;
}
/** 作者 */
- (NSString *)authorForList
{
    return self.listModel.data.author;
}
/** 阅读量 */
- (NSString *)clickForList
{
    return self.listModel.data.click;
}
/** 支持 */
- (NSString *)goodpostForList
{
    return self.listModel.data.goodpost;
}
/** 反对 */
- (NSString *)bagpostForList
{
    return self.listModel.data.badpost;
}
/** 分享时的图片 */
- (NSString *)imageURLForList
{
    return self.listModel.data.image;
}
/** 返回图片数组个数 */
- (NSInteger)numberOfPicsURLForList
{
    return self.listModel.data.pics.count;
}
/** 遍历每张图片地址 */
- (NSURL *)picURLForListIndex:(NSInteger)index
{
    NSURL *url = nil;
    url = [NSURL URLWithString:self.listModel.data.pics[index]];
    
    return url;
}
/** 文字段数 */
- (NSInteger)numberOfContentsForList
{
    return self.listModel.data.content.count;
}
/** 遍历每段详情 */
- (NSString *)contentsForListIndex:(NSInteger)index
{
    return self.listModel.data.content[index];
    
}

/** 评论的数量 */
- (NSInteger)numberOfCommentsForList
{
    return self.listModel.data.comments.list.count;
}

/** 评论里面的属性 */
/** 评论时间 */
- (NSString *)dtimeForCommentsIndex:(NSInteger)index
{
    return self.listModel.data.comments.list[index].dtime;
}
/** 评论者所在地区 */
- (NSString *)ipForCommentsIndex:(NSInteger)index
{
    return self.listModel.data.comments.list[index].ip;
}
/** 评论内容 */
- (NSString *)msgForCommentsIndex:(NSInteger)index
{
    return self.listModel.data.comments.list[index].msg;
}
/** 评论者名称 */
- (NSString *)usernameForCommentsIndex:(NSInteger)index
{
    return self.listModel.data.comments.list[index].username;
}


/** 返回本页的HTML(用于分享) */
- (NSString *)HTMLForListIndex
{
    return self.listModel.data.link;
}



@end




























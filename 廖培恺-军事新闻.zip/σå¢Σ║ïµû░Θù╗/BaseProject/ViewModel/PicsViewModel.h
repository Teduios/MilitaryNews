//
//  PicsViewModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "recommendNetManager.h"

@interface PicsViewModel : BaseViewModel

- (id)initWithAid:(NSString *)aid type:(ActType)type;
@property(nonatomic,strong)NSString *aid;
@property(nonatomic) ActType type;

@property(nonatomic,strong)PicsModel *picsModel;

/** 支持数 */
- (NSString *)goodpostForPics;
/** 反对数 */
- (NSString *)bagpostForPics;
/** 评论数 */
//- (NSInteger)numberOfCountForPics;
/** 图片数 */
- (NSInteger)numberOfPicsForPics;
/** 标题 */
- (NSString *)titleForPics;
/** 图片描述 */
- (NSString *)picstextForPics:(NSInteger)index;
/** 图片地址 */
- (NSURL *)picURLForPics:(NSInteger)index;
/** 图片高度 */
- (NSString *)heightForPics:(NSInteger)index;
/** 图片宽度 */
- (NSString *)widthForPics:(NSInteger)index;

@end

//
//  CommentsListViewModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CommentsListViewModel.h"

@implementation CommentsListViewModel

- (id)initWithAid:(NSString *)aid page:(NSInteger)page
{
    if (self = [super init]) {
        self.aid = aid;
        self.page = page;
    }
    return self;
}

/** 防御性编程，不允许使用init初始化 */
- (id)init{
    if (self = [super init]) {
        //%s->__func__  会显示 哪个类中的哪个方法
        NSAssert1(NO, @"%s 必须使用initWithAid初始化", __func__);
    }
    return self;
}

- (MoreCommentsModel *)moreCommentsModel
{
    if (!_moreCommentsModel) {
        _moreCommentsModel = [[MoreCommentsModel alloc]init];
    }
    return _moreCommentsModel;
}

/** 开始刷新 */
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

/** 加载更多 */
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

/** 获取网络数据 */
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [recommendNetManager getCommentsListWithPage:_page aid:_aid completionHandle:^(MoreCommentsModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data.list];
        completionHandle(error);
    }];
}

- (MoreCommentsListModel *)modelForArr:(NSArray *)arr row:(NSInteger)row
{
    return arr[row];
}

/** 评论的数量 */
- (NSInteger)numberOfCommentsForList
{
    return self.dataArr.count;
}
/** 评论时间 */
- (NSString *)dtimeForCommentsIndex:(NSInteger)index
{
    return [self modelForArr:self.dataArr row:index].dtime;
}
/** 评论者所在地区 */
- (NSString *)ipForCommentsIndex:(NSInteger)index
{
    return [self modelForArr:self.dataArr row:index].ip;
}
/** 评论内容 */
- (NSString *)msgForCommentsIndex:(NSInteger)index
{
    return [self modelForArr:self.dataArr row:index].msg;
}
/** 评论者名称 */
- (NSString *)usernameForCommentsIndex:(NSInteger)index
{
    return [self modelForArr:self.dataArr row:index].msg;
}










































@end

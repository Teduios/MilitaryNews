//
//  ListRecommendViewModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "recommendNetManager.h"

@interface ListRecommendViewModel : BaseViewModel
- (id)initWithAid:(NSString *)aid type:(ActType)type;
@property(nonatomic,strong)NSString *aid;
@property(nonatomic) ActType type;
@property(nonatomic,strong) ListRecommendModel *listModel;

/** 某详情页的题目 */
- (NSString *)titleForList;
/** 发布的日期 */
- (NSString *)pubDataForList;
/** 作者 */
- (NSString *)authorForList;
/** 阅读量 */
- (NSString *)clickForList;
/** 支持 */
- (NSString *)goodpostForList;
/** 反对 */
- (NSString *)bagpostForList;
/** 原始图片 */
- (NSString *)imageURLForList;

/** 图片数组个数 */
- (NSInteger)numberOfPicsURLForList;
/** 可在view层遍历每张图片地址 */
- (NSURL *)picURLForListIndex:(NSInteger)index;

/** 文字的段落数量 */
- (NSInteger)numberOfContentsForList;
/** 在view层遍历每段详情文字 */
- (NSString *)contentsForListIndex:(NSInteger)index;

/** 评论的数量 */
- (NSInteger)numberOfCommentsForList;

/** 评论里面的属性 */
/** 评论时间 */
- (NSString *)dtimeForCommentsIndex:(NSInteger)index;
/** 评论者所在地区 */
- (NSString *)ipForCommentsIndex:(NSInteger)index;
/** 评论内容 */
- (NSString *)msgForCommentsIndex:(NSInteger)index;
/** 评论者名称 */
- (NSString *)usernameForCommentsIndex:(NSInteger)index;

/** 返回HTML */
- (NSString *)HTMLForListIndex;



@end
















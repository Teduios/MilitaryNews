//
//  CommentsListViewModel.h
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "recommendNetManager.h"

@interface CommentsListViewModel : BaseViewModel

- (id)initWithAid:(NSString *)aid page:(NSInteger)page;
@property(nonatomic,strong)NSString *aid;
@property(nonatomic) NSInteger page;
@property(nonatomic,strong) MoreCommentsModel *moreCommentsModel;

/** 评论的数量 */
- (NSInteger)numberOfCommentsForList;

/** 评论里面的属性 */
/** 评论时间 */
- (NSString *)dtimeForCommentsIndex:(NSInteger)index;
/** 评论者所在地区 */
- (NSString *)ipForCommentsIndex:(NSInteger)index;
/** 评论内容 */
- (NSString *)msgForCommentsIndex:(NSInteger)index;
/** 评论者名称 */
- (NSString *)usernameForCommentsIndex:(NSInteger)index;

@end

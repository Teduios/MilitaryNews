//
//  ActionViewModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ActionViewModel.h"

@implementation ActionViewModel

- (id)initWithID:(NSString *)ID action:(NSString *)action
{
    if (self = [super init]) {
        self.ID = ID;
        self.action = action;
    }
    return self;
}

/** 防御性编程，不允许使用init初始化 */
- (id)init{
    if (self = [super init]) {
        //%s->__func__  会显示 哪个类中的哪个方法
        NSAssert1(NO, @"%s 必须使用initWithAid初始化", __func__);
    }
    return self;
}


- (ActionModel *)actionModel
{
    if (!_actionModel) {
        _actionModel = [[ActionModel alloc]init];
    }
    return _actionModel;
}


- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [recommendNetManager getMannerWithID:_ID action:_action completionHandle:^(ActionModel *model, NSError *error) {
        self.actionModel = model;
        completionHandle(error);
    }];
}

/** 支持 */
- (NSInteger)goodpostForAction
{
    return self.actionModel.data.goodpost;
}
/** 反对 */
- (NSString *)bagpostForAction
{
    return self.actionModel.data.badpost;
}



@end

















//
//  PicsViewModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicsViewModel.h"

@implementation PicsViewModel

- (id)initWithAid:(NSString *)aid type:(ActType)type
{
    if (self = [super init]) {
        self.aid = aid;
        self.type = type;
    }
    return self;
}

/** 防御性编程，不允许使用init初始化 */
- (id)init{
    if (self = [super init]) {
        //%s->__func__  会显示 哪个类中的哪个方法
        NSAssert1(NO, @"%s 必须使用initWithAid初始化", __func__);
    }
    return self;
}

- (PicsModel *)picsModel
{
    if (!_picsModel) {
        _picsModel = [[PicsModel alloc]init];
    }
    return _picsModel;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [recommendNetManager getListDetailRecommendWithAid:_aid type:_type completionHandle:^(PicsModel *model, NSError *error) {
        self.picsModel = model;
        completionHandle(error);
    }];
}


/** 支持数 */
- (NSString *)goodpostForPics
{
    return self.picsModel.data.goodpost;
}
/** 反对数 */
- (NSString *)bagpostForPics
{
    return self.picsModel.data.badpost;
}
/** 图片数 */
- (NSInteger)numberOfPicsForPics
{
    return self.picsModel.data.pics.count;
}
/** 标题 */
- (NSString *)titleForPics
{
    return self.picsModel.data.title;
}
/** 具体图片描述 */
- (NSString *)picstextForPics:(NSInteger)index
{
    return [self.picsModel.data.pics[index] valueForKey:@"picstext"];
}
/** 图片地址 */
- (NSURL *)picURLForPics:(NSInteger)index
{
    NSString *path = [self.picsModel.data.pics[index] valueForKey:@"url"];
    return [NSURL URLWithString:path];
}
/** 图片高度 */
- (NSString *)heightForPics:(NSInteger)index
{
    return [self.picsModel.data.pics[index] valueForKey:@"height"];
}
/** 图片宽度 */
- (NSString *)widthForPics:(NSInteger)index
{
    return [self.picsModel.data.pics[index] valueForKey:@"width"];
}


@end














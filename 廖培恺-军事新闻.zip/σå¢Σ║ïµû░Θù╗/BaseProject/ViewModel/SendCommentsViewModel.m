//
//  SendCommentsViewModel.m
//  BaseProject
//
//  Created by apple－jd15 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SendCommentsViewModel.h"

@implementation SendCommentsViewModel
- (id)initSendCommentsWithMsg:(NSString *)msg aid:(NSString *)aid username:(NSString *)username
{
    if (self = [super init]) {
        self.msg = msg;
        self.aid = aid;
        self.username = username;
    }
    return self;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [recommendNetManager postMsgWithMsg:_msg aid:_aid username:_username completionHandle:^(CommentsModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.data.list];
    }];
}

- (CommentsListModel *)modelForArr:(NSArray *)arr row:(NSInteger)row
{
    return arr[row];
}

/** 评论内容 */
- (NSString *)msgForComments:(NSInteger)row
{
    return [self modelForArr:self.dataArr row:row].msg;
}
/** 评论者名称 */
- (NSString *)usernameForComments:(NSInteger)row
{
    return [self modelForArr:self.dataArr row:row].username;
}










@end





